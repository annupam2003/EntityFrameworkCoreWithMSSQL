﻿using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace Chp01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            ListAll();
            ChangeWebUrl(3, "https://www.yahoo.com");
        }

        public static void ListAll()
        {
            using (var db = new AppDbContext())
            {
                foreach (var book in db.Books.AsNoTracking().Include(a => a.Author))
                {
                    var url = book.Author.WebUrl == null ? "Url Not found" : book.Author.WebUrl;
                    Console.WriteLine($"sno-> {book.BookId.ToString().PadLeft(3)} | {book.Title.PadLeft(20)} is written by {book.Author.Name.pan} online avalibale on {url} date of {book.Publishedon:dd/MM/yyyy}");
                }
            }
        }
        public  static void ChangeWebUrl(int id, string url)
        {
            try
            {
                using (var db = new AppDbContext())
                {
                   var book =  db.Books.Include(a=>a.Author).Single(x=>x.AuthorId==id);
                   book.Author.WebUrl=url;
                   db.SaveChanges();
                   ListAll();
                }
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }
        }
    }
}

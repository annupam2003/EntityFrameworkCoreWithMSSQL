dotnet add package Microsoft.EntityFrameworkCore.SqlServer --version 3.1.9
dotnet add package Microsoft.EntityFrameworkCore.Relational --version 3.1.9


create table Author(AuthorId int IDENTITY(1,1), Name varchar(100),WebUrl varchar(500), CONSTRAINT Pk_AuthorId primary key(AuthorId));
Insert Into Author(Name,WebUrl) values('Raj Kumar','http://www.google.com'),('Manoj Singh','http://www.yahoo.com'),('Future Persion',null);
create table Books(BookId int identity(1,1), Title varchar(100), Description varchar(4000),Publishedon datetime default(getdate()),AuthorId int, constraint Pk_BookId primary key(BookId), constraint Fk_AutherId foreign key(AuthorId) references Author(AuthorId) );
Insert Into Books(Title,[Description],Publishedon,AuthorId) values('Maths','Ncert Books for Maths','2020-12-20',1),('Hindi','Ncert Books for Hindi','2020-12-13',1),('English','Ncert Books for Englihs','2019-01-15',2),('Advance Subject','Income ncert Subject','2021-01-01',3);
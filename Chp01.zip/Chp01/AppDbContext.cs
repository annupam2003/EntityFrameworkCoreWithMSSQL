using System;
using Microsoft.EntityFrameworkCore;

namespace Chp01{

    public class AppDbContext : DbContext {
        private const string connection="Server=localhost;Database=Sample;User ID=sa;Password=s@dm1n;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False;";

        protected override void OnConfiguring( DbContextOptionsBuilder builder){
            builder.UseSqlServer(connection);
        }

        public DbSet<Book> Books {get;set;}

    }
}